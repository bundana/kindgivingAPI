<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UrlShortener extends Controller
{
    //
}
